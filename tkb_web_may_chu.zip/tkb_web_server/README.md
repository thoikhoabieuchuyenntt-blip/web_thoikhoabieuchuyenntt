# TKB THPT Chuyên Nguyễn Thiện Thành - bản máy chủ

## Bản này giải quyết đúng việc cần làm

- Website không còn đọc Excel theo kiểu bảng phẳng.
- Đọc đúng cấu trúc Excel TKB của trường: 4 sheet, ô gộp Thứ/Tiết, buổi sáng/chiều, nhiều giáo viên trong một ô.
- Dữ liệu hiện tại đã được nạp sẵn từ file TKB của trường.
- Khi quản trị viên chọn Excel mới và cập nhật, website gửi dữ liệu đã phân tích lên máy chủ.
- Máy chủ lưu dữ liệu vào `data.json`.
- Người khác truy cập website sẽ lấy dữ liệu mới từ máy chủ, không phụ thuộc localStorage của máy quản trị.
- Có mật khẩu quản trị cho thao tác cập nhật.
- Giao diện dùng Times New Roman.

## Chạy trên Windows

### Cách dễ nhất

1. Cài Python 3.10 trở lên.
2. Mở thư mục này.
3. Nhấp đúp `start_server.bat`.
4. Nhập mật khẩu quản trị.
5. Mở Chrome: `http://127.0.0.1:5000`

Mật khẩu mặc định nếu bỏ trống là `thptntt2026`. Nên đổi khi đưa lên Internet.

### Cách bằng Terminal

```powershell
$env:ADMIN_PASSWORD="mat-khau-cua-ban"
python app.py
```

Sau đó mở `http://127.0.0.1:5000`.

**Không mở `index.html` bằng cách double-click** nếu muốn chức năng cập nhật máy chủ hoạt động. Phải chạy `app.py` rồi truy cập qua địa chỉ HTTP.

## Cập nhật TKB

1. Vào tab **Cập nhật dữ liệu**.
2. Chọn file `.xlsx` mới.
3. Nhập mật khẩu quản trị.
4. Bấm **Tải Excel và cập nhật máy chủ**.
5. Nếu thành công, toàn bộ dữ liệu trên website được thay bằng dữ liệu mới.
6. Lịch sử cập nhật được lưu trên máy chủ.

## Đưa lên Internet

Có thể đưa thư mục này lên một máy chủ chạy Python. Cần:

- chạy `python app.py` hoặc cấu hình web service chạy file này;
- đặt biến môi trường `ADMIN_PASSWORD`;
- mở cổng HTTP/HTTPS tương ứng;
- bảo đảm `data.json` nằm trên vùng lưu trữ bền vững.

Nếu nền tảng hosting có filesystem tạm thời, không nên dùng `data.json` lâu dài; khi đó nên đổi sang SQLite/PostgreSQL/Supabase để dữ liệu không mất khi máy chủ khởi động lại.
