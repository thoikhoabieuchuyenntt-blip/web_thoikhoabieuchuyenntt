import json, os, tempfile
from pathlib import Path
from datetime import datetime, timezone
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from urllib.parse import urlparse

BASE = Path(__file__).resolve().parent
DATA_FILE = BASE / 'data.json'
ADMIN_PASSWORD = os.environ.get('ADMIN_PASSWORD', 'thptntt2026')
MAX_BODY = 20 * 1024 * 1024


def read_db():
    if not DATA_FILE.exists():
        return {'data': [], 'meta': {}, 'history': []}
    try:
        return json.loads(DATA_FILE.read_text(encoding='utf-8'))
    except Exception:
        return {'data': [], 'meta': {}, 'history': []}


def write_db(db):
    fd, tmp = tempfile.mkstemp(prefix='tkb_', suffix='.json', dir=str(BASE))
    try:
        with os.fdopen(fd, 'w', encoding='utf-8') as f:
            json.dump(db, f, ensure_ascii=False, indent=2)
        os.replace(tmp, DATA_FILE)
    finally:
        if os.path.exists(tmp):
            os.remove(tmp)


def clean_entries(entries):
    out = []
    for x in entries:
        if not isinstance(x, dict):
            continue
        try:
            day = int(x.get('day', 0))
            period = int(x.get('period', 0))
        except Exception:
            continue
        cls = str(x.get('class', '')).strip()
        subject = str(x.get('subject', '')).strip()
        if not (day and period and cls and subject):
            continue
        teachers = x.get('teachers', [])
        if not isinstance(teachers, list):
            teachers = [str(teachers)] if teachers else []
        teachers = [str(t).strip() for t in teachers if str(t).strip()]
        out.append({
            'day': day,
            'session': str(x.get('session', '')).strip(),
            'period': period,
            'class': cls,
            'subject': subject,
            'teachers': teachers,
            'teacherText': str(x.get('teacherText', '')).strip(),
            'room': str(x.get('room', '')).strip(),
            'sheet': str(x.get('sheet', '')).strip(),
            'raw': str(x.get('raw', '')).strip(),
        })
    return out


class Handler(SimpleHTTPRequestHandler):
    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(BASE), **kwargs)

    def _json(self, status, obj):
        raw = json.dumps(obj, ensure_ascii=False).encode('utf-8')
        self.send_response(status)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Cache-Control', 'no-store')
        self.send_header('Content-Length', str(len(raw)))
        self.end_headers()
        self.wfile.write(raw)

    def do_GET(self):
        path = urlparse(self.path).path
        if path == '/api/schedule':
            return self._json(200, read_db())
        if path == '/api/health':
            db = read_db()
            return self._json(200, {'ok': True, 'lessons': len(db.get('data', []))})
        if path == '/api/download-current':
            return self._json(200, read_db())
        if path == '/':
            self.path = '/index.html'
        return super().do_GET()

    def do_POST(self):
        path = urlparse(self.path).path
        if path != '/api/schedule':
            return self._json(404, {'ok': False, 'error': 'Không tìm thấy API.'})

        try:
            length = int(self.headers.get('Content-Length', '0'))
        except ValueError:
            length = 0
        if length <= 0 or length > MAX_BODY:
            return self._json(413, {'ok': False, 'error': 'Dữ liệu gửi lên quá lớn hoặc không hợp lệ.'})

        try:
            body = json.loads(self.rfile.read(length).decode('utf-8'))
        except Exception:
            return self._json(400, {'ok': False, 'error': 'Dữ liệu JSON không hợp lệ.'})

        if body.get('password') != ADMIN_PASSWORD:
            return self._json(401, {'ok': False, 'error': 'Mật khẩu quản trị không đúng.'})

        entries = clean_entries(body.get('data', []))
        if not entries:
            return self._json(400, {'ok': False, 'error': 'Không nhận được dữ liệu TKB hợp lệ.'})

        meta = body.get('meta') if isinstance(body.get('meta'), dict) else {}
        meta = dict(meta)
        meta['filename'] = str(meta.get('filename', '')).strip() or 'thoi_khoa_bieu.xlsx'
        now = datetime.now(timezone.utc).isoformat()
        meta['uploadedAt'] = now

        item = {
            'filename': meta['filename'],
            'uploadedAt': now,
            'lessons': len(entries),
            'classes': len({x['class'] for x in entries}),
            'teachers': len({t for x in entries for t in x['teachers']}),
            'sheets': len({x['sheet'] for x in entries if x['sheet']}),
            'applied': str(meta.get('applied', '')),
        }
        db_old = read_db()
        history = [item] + [x for x in db_old.get('history', []) if x.get('filename') != item['filename']]
        db = {'data': entries, 'meta': meta, 'history': history[:30]}
        write_db(db)
        return self._json(200, {'ok': True, **db})


if __name__ == '__main__':
    host = os.environ.get('HOST', '127.0.0.1')
    port = int(os.environ.get('PORT', '5000'))
    print(f'TKB server: http://{host}:{port}')
    ThreadingHTTPServer((host, port), Handler).serve_forever()
