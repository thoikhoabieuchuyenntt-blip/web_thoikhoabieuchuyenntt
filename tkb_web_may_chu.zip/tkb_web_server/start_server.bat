@echo off
chcp 65001 >nul
set /p ADMIN_PASSWORD=Nhap mat khau quan tri: 
if "%ADMIN_PASSWORD%"=="" set ADMIN_PASSWORD=thptntt2026
set PORT=5000
python app.py
pause
