import json, re, sys
from datetime import datetime, timezone
from pathlib import Path
from openpyxl import load_workbook

ROOT = Path(__file__).resolve().parents[1]
INPUT = ROOT / 'data' / 'tkb.xlsx'
OUTPUT = ROOT / 'data' / 'schedule.json'


def norm(v):
    if v is None:
        return ''
    return str(v).strip()


def norm_key(v):
    s = norm(v).lower()
    table = str.maketrans('àáạảãâầấậẩẫăằắặẳẵèéẹẻẽêềếệểễìíịỉĩòóọỏõôồốộổỗơờớợởỡùúụủũưừứựửữỳýỵỷỹđ',
                          'aaaaaaaaaaaaaaaaaeeeeeeeeeeeiiiiiooooooooooooooooouuuuuuuuuuuyyyyyd')
    return s.translate(table)


def merge_map(ws):
    out = {}
    for m in ws.merged_cells.ranges:
        value = ws.cell(m.min_row, m.min_col).value
        for r in range(m.min_row, m.max_row + 1):
            for c in range(m.min_col, m.max_col + 1):
                out[(r, c)] = value
    return out


def value(ws, r, c, merges):
    v = ws.cell(r, c).value
    if v not in (None, ''):
        return v
    return merges.get((r, c), '')


def find_header(ws, merges):
    for r in range(1, min(ws.max_row, 30) + 1):
        if norm_key(value(ws, r, 1, merges)) == 'thu' and norm_key(value(ws, r, 2, merges)) == 'tiet':
            return r
    return None


def session_from_sheet(name):
    return 'Chiều' if 'chieu' in norm_key(name) else 'Sáng'


def extract_subjects(wb):
    subjects = set()
    # Match the browser parser: first token is initially treated as subject.
    for ws in wb.worksheets:
        merges = merge_map(ws)
        hr = find_header(ws, merges)
        if not hr:
            continue
        for c in range(3, ws.max_column + 1):
            cl = norm(value(ws, hr, c, merges))
            if not cl:
                continue
            for r in range(hr + 1, ws.max_row + 1):
                raw = norm(value(ws, r, c, merges))
                if not raw:
                    continue
                for line in raw.replace('\r', '').split('\n'):
                    parts = [x.strip() for x in line.split(' - ') if x.strip()]
                    if parts:
                        subjects.add(norm_key(parts[0]))
    return subjects


def split_cell(raw, subject_keys):
    result = []
    for line in norm(raw).replace('\r', '').split('\n'):
        line = line.strip()
        if not line:
            continue
        parts = [x.strip() for x in line.split(' - ') if x.strip()]
        if not parts:
            continue
        subject = parts[0]
        i = 1
        while i < len(parts) and norm_key(parts[i]) in subject_keys:
            subject += ' - ' + parts[i]
            i += 1
        teachers = parts[i:]
        result.append({
            'subject': subject,
            'teachers': teachers,
            'teacherText': ' - '.join(teachers),
            'raw': line,
        })
    return result


def parse():
    if not INPUT.exists():
        raise SystemExit(f'Missing {INPUT}')
    wb = load_workbook(INPUT, data_only=True)
    subject_keys = extract_subjects(wb)
    entries = []
    sheet_meta = {}

    for ws in wb.worksheets:
        merges = merge_map(ws)
        hr = find_header(ws, merges)
        if not hr:
            continue
        session = session_from_sheet(ws.title)
        classes = []
        for c in range(3, ws.max_column + 1):
            cl = norm(value(ws, hr, c, merges))
            if cl:
                classes.append((c, cl))

        day = None
        rows_parsed = 0
        for r in range(hr + 1, ws.max_row + 1):
            raw_day = norm(value(ws, r, 1, merges))
            if raw_day:
                m = re.search(r'\d+', raw_day)
                if m:
                    day = int(m.group())
            raw_period = norm(value(ws, r, 2, merges))
            if norm_key(raw_period) == 'chu nhiem':
                continue
            try:
                period = int(float(raw_period))
            except Exception:
                continue
            if not day or not period:
                continue

            for c, cl in classes:
                raw = norm(value(ws, r, c, merges))
                if not raw:
                    continue
                for item in split_cell(raw, subject_keys):
                    entries.append({
                        'day': day,
                        'session': session,
                        'period': period,
                        'class': cl,
                        'subject': item['subject'],
                        'teachers': item['teachers'],
                        'teacherText': item['teacherText'],
                        'room': '',
                        'sheet': ws.title,
                        'raw': item['raw'],
                    })
                    rows_parsed += 1

        applied = norm(value(ws, 3, 1, merges))
        sheet_meta[ws.title] = {
            'headerRow': hr,
            'session': session,
            'applied': applied,
            'classes': [cl for _, cl in classes],
            'mergedRanges': [str(x) for x in ws.merged_cells.ranges],
            'rowsParsed': rows_parsed,
        }

    if not entries:
        raise SystemExit('No timetable entries found.')

    entries.sort(key=lambda x: (int(x['day']), 0 if x['session'] == 'Sáng' else 1, int(x['period']), x['class'], x['subject']))
    teachers = sorted({t for x in entries for t in x['teachers']})
    classes = sorted({x['class'] for x in entries})
    db = {
        'data': entries,
        'meta': {
            'filename': INPUT.name,
            'generatedAt': datetime.now(timezone.utc).isoformat(),
            'applied': next((m['applied'] for m in sheet_meta.values() if m['applied']), ''),
            'sheets': sheet_meta,
        },
        'history': [{
            'filename': INPUT.name,
            'uploadedAt': datetime.now(timezone.utc).isoformat(),
            'lessons': len(entries),
            'classes': len(classes),
            'teachers': len(teachers),
            'sheets': len(sheet_meta),
            'applied': next((m['applied'] for m in sheet_meta.values() if m['applied']), ''),
        }],
    }
    OUTPUT.write_text(json.dumps(db, ensure_ascii=False, indent=2), encoding='utf-8')
    print(f'Generated {OUTPUT}: {len(entries)} lessons, {len(classes)} classes, {len(teachers)} teachers')


if __name__ == '__main__':
    parse()
