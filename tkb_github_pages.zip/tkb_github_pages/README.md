# TKB THPT Chuyên Nguyễn Thiện Thành - GitHub Pages

Bản này được thiết kế để **đưa thẳng lên GitHub và chạy bằng GitHub Pages**.

## Cách cập nhật TKB toàn trường

Không cần sửa code.

1. Tạo một repository GitHub, ví dụ `tkb-nguyen-thien-thanh`.
2. Upload toàn bộ thư mục này lên repository.
3. Vào **Settings → Pages**.
4. Ở **Source**, chọn **GitHub Actions**.
5. Chờ workflow `Cập nhật và triển khai TKB` chạy xong.
6. Website sẽ có địa chỉ dạng:
   `https://TEN-GITHUB-CUA-BAN.github.io/TEN-REPO/`
7. Khi có Excel mới, vào repository → thư mục `data` → thay file **`tkb.xlsx`** bằng file TKB mới.
8. GitHub Actions tự chạy `scripts/parse_tkb.py`, đọc 4 sheet, tạo `data/schedule.json`, rồi tự triển khai lại website.

### Cấu trúc Excel được hỗ trợ

- `TKB-Buổi chiều`
- `TKB- Buổi sáng`
- `TKB Lớp ĐT-Buổi sáng`
- `TKB Lớp ĐT-Buổi chiều`
- Ô gộp Thứ/Tiết
- Nhiều dòng trong một ô
- Nhiều giáo viên trong một ô
- Lớp đội tuyển `11 (ĐT)`, `12 (ĐT)`
- Không yêu cầu cột `Ngày/Buổi/Tiết/Lớp/Môn/Giáo viên` dạng bảng phẳng

## Lưu ý quan trọng

GitHub Pages là website tĩnh, nên **không thể cho trang web tự ghi file vào repository GitHub** nếu không có hệ thống xác thực/API riêng. Vì vậy cách an toàn ở đây là: quản trị viên thay file `data/tkb.xlsx` trực tiếp trên GitHub; Actions tự động làm phần còn lại.

Không đặt GitHub Personal Access Token trực tiếp trong `index.html`.

## Font

Giao diện dùng **Times New Roman**.
